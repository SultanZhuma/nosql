UNWIND [
  {id:'U001', name:'Aruzhan S.', email:'aruzhan@example.test'},
  {id:'U002', name:'Dias K.', email:'dias@example.test'},
  {id:'U003', name:'Madina T.', email:'madina@example.test'},
  {id:'U004', name:'Timur A.', email:'timur@example.test'},
  {id:'U005', name:'Dana R.', email:'dana@example.test'},
  {id:'U006', name:'Nurlan B.', email:'nurlan@example.test'}
] AS row
MERGE (u:User {userId:row.id}) SET u.name=row.name, u.email=row.email;

UNWIND [
  {id:'R001', name:'Standard Room 101', type:'Room', price:28000, capacity:2, available:true},
  {id:'R002', name:'Twin Room 204', type:'Room', price:32000, capacity:2, available:true},
  {id:'R003', name:'Deluxe Room 305', type:'Room', price:45000, capacity:2, available:false},
  {id:'R004', name:'Family Suite 401', type:'Suite', price:60000, capacity:4, available:true},
  {id:'R005', name:'Meeting Room A', type:'ConferenceRoom', price:50000, capacity:20, available:true},
  {id:'R006', name:'Standard Room 102', type:'Room', price:29000, capacity:2, available:true},
  {id:'R007', name:'Twin Room 205', type:'Room', price:33000, capacity:2, available:false},
  {id:'R008', name:'Apartment 12', type:'Apartment', price:40000, capacity:3, available:true}
] AS row
MERGE (r:Resource {resourceId:row.id})
SET r.name=row.name, r.resourceType=row.type, r.pricePerNight=row.price, r.capacity=row.capacity, r.available=row.available;

UNWIND [
  {id:'L001', name:'Resident City Hotel', city:'Almaty', kind:'Hotel'},
  {id:'L002', name:'Central Almaty', city:'Almaty', kind:'District'},
  {id:'L003', name:'Airport Area', city:'Almaty', kind:'District'},
  {id:'L004', name:'Astana Centre', city:'Astana', kind:'District'},
  {id:'L005', name:'Mountain Resort', city:'Almaty Region', kind:'Resort'}
] AS row
MERGE (l:Location {locationId:row.id}) SET l.name=row.name, l.city=row.city, l.kind=row.kind;

UNWIND [
  {booking:'B001', user:'U001', resource:'R001', checkIn:'2026-11-02', checkOut:'2026-11-05', status:'CONFIRMED'},
  {booking:'B002', user:'U002', resource:'R002', checkIn:'2026-11-04', checkOut:'2026-11-07', status:'CONFIRMED'},
  {booking:'B003', user:'U003', resource:'R003', checkIn:'2026-11-08', checkOut:'2026-11-10', status:'CANCELLED'},
  {booking:'B004', user:'U001', resource:'R004', checkIn:'2026-12-12', checkOut:'2026-12-15', status:'CONFIRMED'},
  {booking:'B005', user:'U004', resource:'R005', checkIn:'2026-11-13', checkOut:'2026-11-13', status:'CONFIRMED'},
  {booking:'B006', user:'U005', resource:'R006', checkIn:'2026-12-01', checkOut:'2026-12-03', status:'CONFIRMED'},
  {booking:'B007', user:'U006', resource:'R008', checkIn:'2026-12-20', checkOut:'2026-12-24', status:'PENDING'},
  {booking:'B008', user:'U002', resource:'R001', checkIn:'2027-01-10', checkOut:'2027-01-12', status:'CONFIRMED'}
] AS row
MATCH (u:User {userId:row.user}) MATCH (r:Resource {resourceId:row.resource})
MERGE (u)-[b:BOOKED {bookingId:row.booking}]->(r)
SET b.checkIn=row.checkIn, b.checkOut=row.checkOut, b.status=row.status;

UNWIND [
  {resource:'R001', location:'L001'}, {resource:'R002', location:'L001'},
  {resource:'R003', location:'L001'}, {resource:'R004', location:'L001'},
  {resource:'R005', location:'L001'}, {resource:'R006', location:'L002'},
  {resource:'R007', location:'L003'}, {resource:'R008', location:'L005'}
] AS row
MATCH (r:Resource {resourceId:row.resource}) MATCH (l:Location {locationId:row.location})
MERGE (r)-[:LOCATED_IN]->(l);

UNWIND [
  {a:'L001', b:'L002', d:2.0}, {a:'L002', b:'L001', d:2.0},
  {a:'L001', b:'L003', d:15.0}, {a:'L003', b:'L001', d:15.0},
  {a:'L002', b:'L005', d:35.0}, {a:'L005', b:'L002', d:35.0},
  {a:'L003', b:'L004', d:700.0}, {a:'L004', b:'L003', d:700.0}
] AS row
MATCH (a:Location {locationId:row.a}) MATCH (b:Location {locationId:row.b})
MERGE (a)-[n:NEAR]->(b) SET n.distanceKm=row.d;
