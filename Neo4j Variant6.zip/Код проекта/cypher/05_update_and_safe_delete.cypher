// Изменение свойства и проверка
MATCH (r:Resource {resourceId:'R008'}) SET r.available = false
RETURN r.resourceId AS id, r.name AS resource, r.available AS available;

// До удаления обязательно проверить выбранную связь
MATCH (u:User {userId:'U006'})-[b:BOOKED {bookingId:'B007'}]->(r:Resource {resourceId:'R008'})
RETURN u.userId AS userId, b.bookingId AS bookingId, r.resourceId AS resourceId, b.status AS status;

// Удалить только проверенную связь
MATCH (u:User {userId:'U006'})-[b:BOOKED {bookingId:'B007'}]->(r:Resource {resourceId:'R008'})
DELETE b;

// Проверка: ожидается 0 строк
MATCH (:User {userId:'U006'})-[b:BOOKED {bookingId:'B007'}]->(:Resource {resourceId:'R008'})
RETURN b;
