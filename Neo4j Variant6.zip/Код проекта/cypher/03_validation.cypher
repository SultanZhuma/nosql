MATCH (n) RETURN labels(n) AS labels, count(*) AS qty ORDER BY labels;
MATCH ()-[r]->() RETURN type(r) AS relationship, count(*) AS qty ORDER BY relationship;
MATCH p=(a)-[r]->(b) RETURN p LIMIT 50;
