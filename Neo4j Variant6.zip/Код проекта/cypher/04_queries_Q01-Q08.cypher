// Q01
MATCH (u:User) RETURN u.userId AS id, u.name AS name ORDER BY name;

// Q02
MATCH (r:Resource) WHERE r.available = true AND r.pricePerNight <= 40000
RETURN r.name AS resource, r.resourceType AS type, r.pricePerNight AS price ORDER BY price;

// Q03
MATCH (r:Resource) WHERE r.available = true
RETURN r.name AS resource, r.pricePerNight AS price ORDER BY price ASC LIMIT 3;

// Q04
MATCH (u:User {userId:'U001'})-[b:BOOKED]->(r:Resource)
RETURN u.name AS user, b.bookingId AS booking, b.status AS status, r.name AS resource, b.checkIn AS checkIn, b.checkOut AS checkOut ORDER BY b.checkIn;

// Q05
MATCH (u:User {userId:'U001'})-[:BOOKED]->(r:Resource)-[:LOCATED_IN]->(l:Location)
RETURN u.name AS user, r.name AS resource, l.name AS location, l.city AS city;

// Q06
MATCH (start:Location {locationId:'L001'})-[:NEAR*1..2]->(other:Location)
WHERE other <> start
RETURN DISTINCT start.name AS from, other.name AS reachableLocation, other.city AS city ORDER BY reachableLocation;

// Q07
MATCH (u:User) OPTIONAL MATCH (u)-[b:BOOKED]->(:Resource)
RETURN u.name AS user, count(b) AS bookings ORDER BY bookings DESC, user;

// Q08
MATCH (base:Location {locationId:'L001'})-[:NEAR*1..2]->(near:Location)
MATCH (r:Resource)-[:LOCATED_IN]->(near)
WHERE r.available = true
RETURN DISTINCT r.name AS alternative, r.resourceType AS type, r.pricePerNight AS price, near.name AS location ORDER BY price;
