#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
CONTAINER="neo4j-booking-lab7"
DB_USER="neo4j"
DB_PASSWORD="Lab7BookingPass123"

printf '\n[1/4] Запускаю Neo4j...\n'
docker compose up -d

printf '[2/4] Ожидаю готовности Neo4j'
ready=0
for i in $(seq 1 60); do
  if docker exec "$CONTAINER" cypher-shell -u "$DB_USER" -p "$DB_PASSWORD" "RETURN 'ready' AS status" >/dev/null 2>&1; then
    ready=1
    break
  fi
  printf '.'
  sleep 2
done
printf '\n'
if [[ "$ready" -ne 1 ]]; then
  echo "Neo4j не готов. Проверьте логи: docker compose logs neo4j" >&2
  exit 1
fi

run_cypher() {
  local file="$1"
  printf '\n>>> %s\n' "$file"
  docker exec "$CONTAINER" cypher-shell -u "$DB_USER" -p "$DB_PASSWORD" --format plain -f "/cypher/$file"
}

printf '[3/4] Создаю ограничения и синтетические данные...\n'
run_cypher "01_constraints.cypher"
run_cypher "02_seed_data.cypher"

printf '\n[4/4] Проверяю структуру графа...\n'
run_cypher "03_validation.cypher"

cat <<'MSG'

Готово. Neo4j Browser: http://localhost:7474
Демонстрационные запросы: Код проекта/cypher/04_queries_Q01-Q08.cypher
Изменение и безопасное удаление: Код проекта/cypher/05_update_and_safe_delete.cypher
Внимание: перед удалением выполните и проверьте запрос с RETURN в этом файле.
MSG
